A Pen created at CodePen.io. You can find this one at https://codepen.io/ericrasch/pen/zjDBx.

 Style a Select Box Using Only CSS. Inspired by: http://bavotasan.com/2011/style-select-box-using-only-css/