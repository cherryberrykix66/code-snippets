// No! The whole point is this is CSS-only.
// Be sure to check these in IE9/8/7... which is why I'm testing so many versions of select styles.​​​